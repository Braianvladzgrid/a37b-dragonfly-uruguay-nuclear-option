var config_dlg = gui.Dialog.new("/sim/gui/dialogs/config/dialog", "Aircraft/Cessna-A37-Dragonfly/Dialogs/config.xml");
