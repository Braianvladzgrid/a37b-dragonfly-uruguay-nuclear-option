# ==========================================#
# mass management BARANGER Emmanuel 03/2025 #
# Update for Cessna A37 Dragonfly   02/2026 #
# ==========================================#

redo = 1;

var massmanage = func {

  setprop("sim/weight[0]/selected",getprop("sim/weight[0]/opt[0]/name"));
  setprop("sim/weight[1]/selected",getprop("sim/weight[1]/opt[0]/name"));
  setprop("sim/weight[2]/selected",getprop("sim/weight[2]/opt[0]/name"));
  setprop("sim/weight[3]/selected",getprop("sim/weight[3]/opt[0]/name"));
  setprop("sim/weight[0]/weight-lb",getprop("sim/weight[0]/opt[0]/lbs"));
  setprop("sim/weight[1]/weight-lb",getprop("sim/weight[1]/opt[0]/lbs"));
  setprop("sim/weight[2]/weight-lb",getprop("sim/weight[2]/opt[0]/lbs"));
  setprop("sim/weight[3]/weight-lb",getprop("sim/weight[3]/opt[0]/lbs"));
  setprop("consumables/fuel/tank[4]/level-lbs",getprop("sim/weight[0]/opt[0]/lbs"));
  setprop("consumables/fuel/tank[5]/level-lbs",getprop("sim/weight[1]/opt[0]/lbs"));
  setprop("consumables/fuel/tank[6]/level-lbs",getprop("sim/weight[2]/opt[0]/lbs"));
  setprop("consumables/fuel/tank[7]/level-lbs",getprop("sim/weight[3]/opt[0]/lbs"));

  #----------------------------------------------------------------------------------------
  # sim/model/show-tank1
  var hidetank1  = props.globals.getNode("sim/multiplay/generic/bool[17]",1);
  var wingstank1 = hidetank1.getBoolValue();
  if ( wingstank1 == 1 ) {
    setprop("sim/weight[0]/selected",getprop("sim/weight[0]/opt[1]/name"));
    setprop("sim/weight[0]/weight-lb",getprop("sim/weight[0]/opt[1]/lbs"));
    setprop("consumables/fuel/tank[4]/level-lbs",getprop("sim/weight[0]/opt[1]/lbs"));

    setprop("sim/weight[3]/selected",getprop("sim/weight[3]/opt[1]/name"));
    setprop("sim/weight[3]/weight-lb",getprop("sim/weight[3]/opt[1]/lbs"));
    setprop("consumables/fuel/tank[5]/level-lbs",getprop("sim/weight[3]/opt[1]/lbs"));
  }

  # sim/model/show-tank2
  var hidetank2  = props.globals.getNode("sim/multiplay/generic/bool[18]",1);
  var wingstank2 = hidetank2.getBoolValue();
  if ( wingstank2 == 1 ) {
    setprop("sim/weight[1]/selected",getprop("sim/weight[1]/opt[1]/name"));
    setprop("sim/weight[1]/weight-lb",getprop("sim/weight[1]/opt[1]/lbs"));
    setprop("consumables/fuel/tank[6]/level-lbs",getprop("sim/weight[1]/opt[1]/lbs"));

    setprop("sim/weight[2]/selected",getprop("sim/weight[2]/opt[1]/name"));
    setprop("sim/weight[2]/weight-lb",getprop("sim/weight[2]/opt[1]/lbs"));
    setprop("consumables/fuel/tank[7]/level-lbs",getprop("sim/weight[2]/opt[1]/lbs"));
  }

  #----------------------------------------------------------------------------------------
  # sim/model/show-suu1
  var hidesuu1  = props.globals.getNode("sim/multiplay/generic/bool[19]",1);
  var wingssuu1 = hidesuu1.getBoolValue();
  if ( wingssuu1 == 1 ) {
    setprop("sim/weight[0]/selected",getprop("sim/weight[0]/opt[2]/name"));
    setprop("sim/weight[0]/weight-lb",getprop("sim/weight[0]/opt[2]/lbs"));

    setprop("sim/weight[3]/selected",getprop("sim/weight[3]/opt[2]/name"));
    setprop("sim/weight[3]/weight-lb",getprop("sim/weight[3]/opt[2]/lbs"));
  }

  # sim/model/show-suu2
  var hidesuu2  = props.globals.getNode("sim/multiplay/generic/bool[20]",1);
  var wingssuu2 = hidesuu2.getBoolValue();
  if ( wingssuu2 == 1 ) {
    setprop("sim/weight[1]/selected",getprop("sim/weight[1]/opt[2]/name"));
    setprop("sim/weight[1]/weight-lb",getprop("sim/weight[1]/opt[2]/lbs"));

    setprop("sim/weight[2]/selected",getprop("sim/weight[2]/opt[2]/name"));
    setprop("sim/weight[2]/weight-lb",getprop("sim/weight[1]/opt[2]/lbs"));
  }

  #----------------------------------------------------------------------------------------
  # sim/model/show-cbu241
  var hidecbu241  = props.globals.getNode("sim/multiplay/generic/bool[21]",1);
  var wingscbu241 = hidecbu241.getBoolValue();
  if ( wingscbu241 == 1 ) {
    setprop("sim/weight[0]/selected",getprop("sim/weight[0]/opt[3]/name"));
    setprop("sim/weight[0]/weight-lb",getprop("sim/weight[0]/opt[3]/lbs"));

    setprop("sim/weight[3]/selected",getprop("sim/weight[3]/opt[3]/name"));
    setprop("sim/weight[3]/weight-lb",getprop("sim/weight[3]/opt[3]/lbs"));
  }

  # sim/model/show-cbu242
  var hidecbu242  = props.globals.getNode("sim/multiplay/generic/bool[22]",1);
  var wingscbu242 = hidecbu242.getBoolValue();
  if ( wingscbu242 == 1 ) {
    setprop("sim/weight[1]/selected",getprop("sim/weight[1]/opt[2]/name"));
    setprop("sim/weight[1]/weight-lb",getprop("sim/weight[1]/opt[3]/lbs"));

    setprop("sim/weight[2]/selected",getprop("sim/weight[2]/opt[2]/name"));
    setprop("sim/weight[2]/weight-lb",getprop("sim/weight[2]/opt[3]/lbs"));
  }

  if ( redo == 1 ) {
    settimer(massmanage, 0);
    redo = 0;
  }

}

massmanage();
